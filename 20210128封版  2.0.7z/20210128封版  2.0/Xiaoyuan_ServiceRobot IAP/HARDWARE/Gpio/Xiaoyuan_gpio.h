#ifndef _XIAOYUAN_GPIO_H_
#define _XIAOYUAN_GPIO_H_

#include "Xiaoyuan_sys.h"

#define BRAKE_Disable 				GPIOE->BSRRL=GPIO_Pin_8				
#define BRAKE_Enable					GPIOE->BSRRH=GPIO_Pin_8	

#define POWER12V_Enable 			GPIOE->BSRRH=GPIO_Pin_0			
#define POWER12V_Disable			GPIOE->BSRRL=GPIO_Pin_0				
#define POWER5V_Enable 				GPIOE->BSRRL=GPIO_Pin_1				
#define POWER5V_Disable				GPIOE->BSRRH=GPIO_Pin_1
#define POWER19V_Enable 			GPIOE->BSRRL=GPIO_Pin_15				
#define POWER19V_Disable			GPIOE->BSRRH=GPIO_Pin_15	
#define IAP_Lighting				 (GPIO_ToggleBits(GPIOE,GPIO_Pin_2),GPIO_ToggleBits(GPIOE,GPIO_Pin_3),GPIO_ToggleBits(GPIOE,GPIO_Pin_4),GPIO_ToggleBits(GPIOE,GPIO_Pin_5))


#define WATERLEVEL_1_POWER_ENABLE 	PEout(9)
#define WATERLEVEL_2_POWER_ENABLE 	PEout(10)


#define JDQ_Bush_On					GPIOC->BSRRL=GPIO_Pin_13			
#define JDQ_Bush_Off				GPIOC->BSRRH=GPIO_Pin_13		
#define JDQ_XISHUI_On				GPIOC->BSRRL=GPIO_Pin_12		
#define JDQ_XISHUI_Off				GPIOC->BSRRH=GPIO_Pin_12

#define DCF_CHUISHUI_On				GPIOB->BSRRL=GPIO_Pin_5		
#define DCF_CHUISHUI_Off			GPIOB->BSRRH=GPIO_Pin_5

#define ALARM_LIGHT_ENABLE			GPIOB->BSRRL=GPIO_Pin_3
#define ALARM_LIGHT_DISABLE			GPIOB->BSRRH=GPIO_Pin_3

#define XISHUI_TUIGAN_DOWN			(GPIOC->BSRRH=GPIO_Pin_8, GPIOC->BSRRL=GPIO_Pin_9)
#define XISHUI_TUIGAN_UP						(GPIOC->BSRRL=GPIO_Pin_8, GPIOC->BSRRH=GPIO_Pin_9)

#define SHUAPAN_TUIGAN_DOWN			(GPIOC->BSRRL=GPIO_Pin_10, GPIOC->BSRRH=GPIO_Pin_11)
#define SHUAPAN_TUIGAN_UP						(GPIOC->BSRRH=GPIO_Pin_10, GPIOC->BSRRL=GPIO_Pin_11)

//#define XISHUI_TUIGAN_UP			(GPIOC->BSRRH=GPIO_Pin_10, GPIOC->BSRRL=GPIO_Pin_9)
//#define XISHUI_TUIGAN_DOWN			(GPIOC->BSRRL=GPIO_Pin_10, GPIOC->BSRRH=GPIO_Pin_9)

//#define SHUAPAN_TUIGAN_UP			(GPIOC->BSRRL=GPIO_Pin_8, GPIOC->BSRRH=GPIO_Pin_11)
//#define SHUAPAN_TUIGAN_DOWN			(GPIOC->BSRRH=GPIO_Pin_8, GPIOC->BSRRL=GPIO_Pin_11)

extern unsigned char RobotClearStatus;
extern unsigned char TurnLightStatus;
extern unsigned char DCF_CHUISHUI_Status;			

void Xiaoyuan_GPIO_Init(void);



#endif


