#include "Xiaoyuan_gpio.h"
#include "Xiaoyuan_time.h"
#include "stdbool.h"

void Xiaoyuan_GPIO_Init(void)
{    	 
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 |GPIO_Pin_3 | GPIO_Pin_4|GPIO_Pin_5 ;											
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	

	
//	POWER5V_Enable;
//	POWER19V_Enable;
//	POWER12V_Enable;	
//	
//	WATERLEVEL_1_POWER_ENABLE = 1;
//	WATERLEVEL_2_POWER_ENABLE = 1;
	
}


unsigned char RobotClearStatus = 0x00;
unsigned char TurnLightStatus = 0xff;
unsigned int SystemTimer = 0;
bool MotoStatus = false;







