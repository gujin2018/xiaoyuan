#ifndef _XIAOYUAN_LIGHT_H_
#define _XIAOYUAN_LIGHT_H_
#include "Xiaoyuan_sys.h"


#define BLUE_LIGHT_Enable 					GPIOD->BSRRL=GPIO_Pin_11			
#define BLUE_LIGHT_Disable					GPIOD->BSRRH=GPIO_Pin_11				
#define LEFT_LIGHT_Enable 					GPIOD->BSRRL=GPIO_Pin_12			
#define LEFT_LIGHT_Disable					GPIOD->BSRRH=GPIO_Pin_12
#define RIGHT_LIGHT_Enable 					GPIOD->BSRRL=GPIO_Pin_10				
#define RIGHT_LIGHT_Disable					GPIOD->BSRRH=GPIO_Pin_10	

#define FAR_LIGHT_Enable 					GPIOD->BSRRL=GPIO_Pin_9			
#define FAR_LIGHT_Disable					GPIOD->BSRRH=GPIO_Pin_9
#define NEAR_LIGHT_Enable 					GPIOD->BSRRL=GPIO_Pin_8				
#define NEAR_LIGHT_Disable					GPIOD->BSRRH=GPIO_Pin_8	

#define BLUE_LIGHT_CONTROL		PDout(11)
#define LEFT_LIGHT_CONTROL		PDout(12)
#define RIGHT_LIGHT_CONTROL		PDout(10)


void Xiaoyuan_LIGHT_init(void);
void Xiaoyuan_LIGHT_ctrl(void);
#endif


