#include "Xiaoyuan_light.h"
#include "Xiaoyuan_usart.h"
#include "Xiaoyuan_moto.h"
#include "Xiaoyuan_time.h"
#include "Xiaoyuan_gpio.h"

/**
 @ BLUE_LIGHT = PD11
 @ LEFT_LIGHT = PD12
 @ RIGHT_LIGHT = PD10
 @ FAR_LIGHT = PD10
 @ NEAR_LIGHT = PD10 
**/

void Xiaoyuan_LIGHT_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD , ENABLE);

	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	BLUE_LIGHT_Enable;
}


void Xiaoyuan_LIGHT_ctrl(void)
{
	switch(TurnLightStatus)		//����-����ͷ-���װ�----ת�����ǰ���ڷ�װ�ӿ�
	{
		case 0xaa: LEFT_LIGHT_CONTROL=1; break;
		case 0xbb: RIGHT_LIGHT_CONTROL = 1; break;
		case 0xcc: 
			LEFT_LIGHT_CONTROL = 0;
			RIGHT_LIGHT_CONTROL = 0;
			break;
	}

	if(TurnLightStatus == 0xff || TurnLightStatus == 0xcc)	//�����λ��û�з��Ϳ���ָ�������λ������ת��ƹرյ�ʱ��
	{
		if(Left_Feedback_Information_Str.Current_Wheel_Speed >= 0 && Right_Feedback_Information_Str.Current_Wheel_Speed >= 0)
		{
			if((Left_Feedback_Information_Str.Current_Wheel_Speed - Right_Feedback_Information_Str.Current_Wheel_Speed)  < (-0.1f))
			{
				LEFT_LIGHT_CONTROL = 1;
			}
			else if((Left_Feedback_Information_Str.Current_Wheel_Speed - Right_Feedback_Information_Str.Current_Wheel_Speed)  > 0.1f)
			{
				RIGHT_LIGHT_CONTROL = 1;
			}
			else
			{
				LEFT_LIGHT_CONTROL = 0;
				RIGHT_LIGHT_CONTROL = 0;
			}
		}
	}
}


void Xiaoyuan_LIGHT2_ctrl(void)
{
	
	static unsigned char turn_light_status,turn_light_count;
	static unsigned int forward_light_count;
	if(Left_Feedback_Information_Str.Current_Wheel_Speed >= 0 && Right_Feedback_Information_Str.Current_Wheel_Speed >= 0)
	{
		//	turn left
		if((Left_Feedback_Information_Str.Current_Wheel_Speed - Right_Feedback_Information_Str.Current_Wheel_Speed)  < -0.07f)
		{
			if(turn_light_status != 0xAA)
			{
					turn_light_count++;
					if(turn_light_count ==10)
					{
						RIGHT_LIGHT_Disable;
						LEFT_LIGHT_Enable;
						turn_light_status = 0xAA;
						turn_light_count = 0;
					}
			}
			forward_light_count = Safeware_Count;
		}		
		// 	turn right
		else if((Left_Feedback_Information_Str.Current_Wheel_Speed - Right_Feedback_Information_Str.Current_Wheel_Speed)  > 0.07f)
		{
			if(turn_light_status != 0xBB)
			{
					turn_light_count++;
					if(turn_light_count ==10)
					{
						LEFT_LIGHT_Disable;	
						RIGHT_LIGHT_Enable;
						turn_light_status = 0xBB;
						turn_light_count = 0;		
					}
			}
			forward_light_count = Safeware_Count;
		}	
		//	foward  //after 500ms
		else if(turn_light_status != 0x00) 
		{
				if((Safeware_Count - forward_light_count) >=10)
				{
					LEFT_LIGHT_Disable;
					RIGHT_LIGHT_Disable;
					turn_light_status = 0x00;
					turn_light_count = 0;
				}
		}		
	}		
}	

