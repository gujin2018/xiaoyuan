#include "Xiaoyuan_time.h"
#include "Xiaoyuan_led.h"
#include "Xiaoyuan_encoder.h"
#include "Xiaoyuan_moto.h"
#include "Xiaoyuan_pid.h"
#include "Xiaoyuan_usart.h"


/*
* describetion: The timer overflow interrupt initializes the configuration
* param: arr:Automatic reload value
				 psc:Clock Prescale Number
* return: none
* author: Xuewei Zhou
* date : 2016-11-27
* note:Tout=((arr+1)*(psc+1))/Ft us.
*/
void BaseBoard_TIM7_Init(u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7,ENABLE);  
	
	TIM_TimeBaseInitStructure.TIM_Period = arr; 	
	TIM_TimeBaseInitStructure.TIM_Prescaler=psc;  
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up; 
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1; 
	
	TIM_TimeBaseInit(TIM7,&TIM_TimeBaseInitStructure);
	
	TIM_ITConfig(TIM7,TIM_IT_Update,ENABLE); 
	TIM_Cmd(TIM7,ENABLE); 
	
	NVIC_InitStructure.NVIC_IRQChannel=TIM7_IRQn; 
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x01;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x03; 
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}


void TIM6_Init(u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,ENABLE);  
	
	TIM_TimeBaseInitStructure.TIM_Period = arr; 	
	TIM_TimeBaseInitStructure.TIM_Prescaler=psc;  
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up; 
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1; 
	
	TIM_TimeBaseInit(TIM6,&TIM_TimeBaseInitStructure);
	
	TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE); 
	TIM_Cmd(TIM6,ENABLE); 
	
	NVIC_InitStructure.NVIC_IRQChannel=TIM6_DAC_IRQn; 
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x02;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x03; 
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}


/*
* describetion: time6 interrupt function
* param��none
* return: none
* author: Xuewei Zhou
* date : 2016-12-1
* speed = encoder_value/(TTL_MOTO)/time*60;
*/
//Program run time count
unsigned int Safeware_Count = 0;
unsigned int Commnication_Count = 0;
void TIM7_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM7,TIM_IT_Update)==SET) 
	{
		//program runing time ccount add
//		(Safeware_Count == 42949672) ?(Safeware_Count=0) : (Safeware_Count++);
//		
//		Xiaoyuan_Encoder_Get_CNT();	//��ȡ�������ӵı�������ֵ
//		
//		LED4 = ~LED4;
	}
	TIM_ClearITPendingBit(TIM7,TIM_IT_Update);  
}

/*
 *describetion: Get ADC Get_Adc_Average    TIM6 :  T = 10ms
 *author: GuJin
*/

void TIM6_DAC_IRQnHandler(void)
{
	if(TIM_GetITStatus(TIM6,TIM_IT_Update)==SET) 
	{
		//program runing time ccount add
		(Safeware_Count == 42949672) ?(Safeware_Count=0) : (Safeware_Count++);
		
		Xiaoyuan_Encoder_Get_CNT();	//��ȡ�������ӵı�������ֵ
		
		LED4 = ~LED4;
	}
	TIM_ClearITPendingBit(TIM6,TIM_IT_Update);  
}

