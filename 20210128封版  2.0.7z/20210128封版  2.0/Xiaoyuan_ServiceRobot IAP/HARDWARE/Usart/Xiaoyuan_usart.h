#ifndef __XIAOYUAN_USART_H
#define __XIAOYUAN_USART_H


#include "stdio.h"	
#include "stm32f4xx_conf.h"
#include "Xiaoyuan_sys.h" 
#include <stdbool.h>


typedef   enum
{
    Status0 = 0,
	  Status1,															//head �ϵ縴λ�ɹ�
    Status2,
    Status3,
    Status4,
	  Status5,
		Status6,
		Status7,
		Status8,
		Status9,
		Status10
}StateStatus;


typedef union _UsartSend_Union
{
	unsigned char Send_Buffer[5];
//	unsigned int content;
	struct _UsartSend_Struct
	{
		unsigned short head;
		unsigned char status;
		unsigned char time;
		unsigned char check;
	}UsartSend_Struct;
}UsartSend_Union;

extern UsartSend_Union Usart1_Send;
extern StateStatus HeadStatus,LastStatus;
void Robot_Usart_Init(u32 bound);
void USART1_SendChar(unsigned char b);

#define USART_REC_LEN  			120*1024 //�����������ֽ��� 120K
#define head_update 0xAA
#define clear_update 0xBB

extern u32 USART_RX_CNT;
extern u8 USART_RX_BUF[USART_REC_LEN];
#define TRANSMISSION_BUF_SIZE		5 	
#define TRANSMISSION_BUF_HEADER		0XBBAA
#define TRANSMISSION_BUF_CHECKSUM	0XEE

void USART1_SendStatus(unsigned char status,unsigned char time) ;
void Robot_Usart_Init(u32 bound);
void USART1_SendChar(unsigned char b); 
 

#endif


