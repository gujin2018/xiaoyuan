#ifndef _XIAOYUAN_ADC_H_
#define _XIAOYUAN_ADC_H_

#include "Xiaoyuan_sys.h"



/** 
 @ US1 - PC0
 @ US2 - PC1
 @ US3 - PA2
 @ US4 - PA3
 @ US5 - PA5
 @ ACC - PC2
 @ Current - PC4 
**/
	 
extern volatile unsigned short ADC_ConvertedValue[7];
extern volatile   float ADC_Value[7];

#define US1_ADC_CHANNEL 		ADC_Channel_10                   //PC0-YEWEI1    0.6v-3v    
#define US2_ADC_CHANNEL 		ADC_Channel_11										//PC1-YEWEI2
#define US3_ADC_CHANNEL 		ADC_Channel_2
#define US4_ADC_CHANNEL 		ADC_Channel_3
#define US5_ADC_CHANNEL 		ADC_Channel_13                   //PC13-VOLTAGE  1/16 27/16 = 1.68v
#define ACC_ADC_CHANNEL 		ADC_Channel_12                 //PC2-YOUMEN
#define Current_ADC_CHANNEL 	ADC_Channel_14               //PC4-CURRENT

void Xiaoyuan_ADC_Init(void); 		
#endif


