#ifndef _XIAOYUAN_POSE_H_
#define _XIAOYUAN_POSE_H_
//http://www.bspilot.com/?p=145

#include "Xiaoyuan_sys.h"
#include <string.h>


#define DMA_USART_RX_SIZE	33
extern unsigned char DMAmemoryBuff[DMA_USART_RX_SIZE];


#define TRANSMISSION_BUF_SIZE		46 	
#define TRANSMISSION_BUF_HEADER		0XFFFFFFFF
#define TRANSMISSION_BUF_CHECKSUM	0XEE

#pragma pack(1)

typedef struct __Pose_Frame_ID_Str_
{
	short X_data;
	short Y_data;
	short Z_data;
	short Timer;
}Pose_Frame_ID_Str_;

typedef union __Commnication_moven_Union_
{
	unsigned char Transmission_Buffer[TRANSMISSION_BUF_SIZE];
	struct __Commnication_move_Stru_
	{
		unsigned int header;
		
		Pose_Frame_ID_Str_ BaseLink_Accelerometer;
		Pose_Frame_ID_Str_ BaseLink_Gyroscope;	
		Pose_Frame_ID_Str_ BaseLink_Magnetometer;
		
		float Position_X;
		float Position_Y;
		float Orientation_Z;
		
		unsigned char Distence_Sensor_buf[5];
		
		unsigned char Check_sum;
		
	}Commnication_move_Stru_;
}Commnication_move_Union;

#pragma pack(4)

extern Commnication_move_Union  Send_Commnication_move_Union;
extern Commnication_move_Union  Reci_Commnication_move_Union;



void MPU9250_DMA_Usart_Configure(unsigned int bound);
void Process_Mpu_pose_data(unsigned char* Databuf);
void Calibration_IMU_function(void);

#endif


