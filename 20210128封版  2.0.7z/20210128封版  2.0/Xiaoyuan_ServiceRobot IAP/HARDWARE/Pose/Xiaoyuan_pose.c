#include "Xiaoyuan_pose.h"
#include "Xiaoyuan_led.h"
#include "Xiaoyuan_delay.h"
#include "Xiaoyuan_usart.h"

/*----PA0-----TX----*/
/*----PA1-----RX----*/

void DMA1_Stream2_UART4_Rx(void);

unsigned char DMAmemoryBuff[DMA_USART_RX_SIZE];

Commnication_move_Union  Send_Commnication_move_Union;
Commnication_move_Union  Reci_Commnication_move_Union;

/*
 @ describetion: MPU9250 Usart RX DMA init configure
 @ param:  unsigned int bound
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void MPU9250_DMA_Usart_Configure(unsigned int bound)
*/
void MPU9250_DMA_Usart_Configure(unsigned int bound)
{    	 
	GPIO_InitTypeDef GPIO_InitStructure; 
	USART_InitTypeDef USART_InitStructure; 
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA  ,ENABLE); 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE);
															  
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource0,GPIO_AF_UART4); 
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource1,GPIO_AF_UART4);    
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP; 
	GPIO_Init(GPIOA,&GPIO_InitStructure);    

	USART_InitStructure.USART_BaudRate=bound; 
	USART_InitStructure.USART_Parity=USART_Parity_No;
	USART_InitStructure.USART_WordLength=USART_WordLength_8b; 
	USART_InitStructure.USART_StopBits=USART_StopBits_1; 
	USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None; 
	USART_InitStructure.USART_Mode=USART_Mode_Rx|USART_Mode_Tx; 
	USART_Init(UART4, &USART_InitStructure);    

	USART_ITConfig(UART4, USART_IT_IDLE, ENABLE); 	//enable free interrupt 
	USART_Cmd(UART4, ENABLE);
	
	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	USART_ClearFlag(UART4, USART_FLAG_TC); 
	
	// Init DMA between Memory or Usart configure
	USART_DMACmd(UART4,USART_DMAReq_Rx,ENABLE);
	DMA1_Stream2_UART4_Rx();
}

/*
 @ describetion: Xiaoyuan KEYEXIT_Init function
 @ param:  none
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Xiaoyuan_LED_Init(void)
*/
void DMA1_Stream2_UART4_Rx(void)
{
	DMA_InitTypeDef  DMA_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1,ENABLE);						// DMA1 clock enable
	DMA_DeInit(DMA1_Stream2);
	
	while (DMA_GetCmdStatus(DMA1_Stream2) != DISABLE){}						// Wait the DMA configure can be setting

	DMA_InitStructure.DMA_Channel = DMA_Channel_4;  						// choose channel_4
	DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)&UART4->DR;				// DMA perpheral address
	DMA_InitStructure.DMA_Memory0BaseAddr = (u32)&DMAmemoryBuff;		   // DMA start storage address
		
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;					// Memory To UART4
	DMA_InitStructure.DMA_BufferSize = DMA_USART_RX_SIZE;					// data tx size
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;	// device data length
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;			// Memory data length
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;					//�е����ȼ�
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;				
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;		
		
	DMA_Init(DMA1_Stream2, &DMA_InitStructure);
    DMA_Cmd(DMA1_Stream2, ENABLE);  
}
/*
 @ describetion: process mpu9250 data function
 @ param:  none
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Process_Mpu_pose_data(unsigned char* Databuf)
*/
void Process_Mpu_pose_data(unsigned char* Databuf)
{
	if(Databuf[0] == 0x55 && Databuf[1] == 0x51)
	{
		memcpy(&Send_Commnication_move_Union.Commnication_move_Stru_.BaseLink_Accelerometer, &Databuf[2], 4*sizeof(short));
		memcpy(&Send_Commnication_move_Union.Commnication_move_Stru_.BaseLink_Gyroscope, &Databuf[13], 4*sizeof(short));
		memcpy(&Send_Commnication_move_Union.Commnication_move_Stru_.BaseLink_Magnetometer, &Databuf[24], 4*sizeof(short));
	}	
}



/*
* describetion: usart send a char data 
* param: b:data
* return: none
* author: Xuewei Zhou
* date : 2016-11-29
*/
void UART4_SendChar(unsigned char b)
{
	while (USART_GetFlagStatus(UART4,USART_FLAG_TC) == RESET){}
		USART_SendData(UART4,b);
		
	LED2 = ~LED2;
}


/*
 @ describetion: Calibration imu Function
 @ param:  none
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Calibration_IMU_function()
*/
void Calibration_IMU_function()
{
	unsigned char i;
	
	unsigned char Calibration_IMU[5]= {0xff, 0xaa, 0x01, 0x08, 0x00};
/*
	unsigned char Calibration_IMU_Commend[8][5] = {	
				 {0xFF, 0xAA, 0x00, 0x01, 0x00},		//�ָ���ʼ����
				 {0xff, 0xaa, 0x24, 0x01, 0x00},		//����6���㷨
				 {0xff, 0xaa, 0x02, 0x16, 0x00},		//�ر�ŷ�������
				 {0xff, 0xaa, 0x01, 0x08, 0x00},		//�رմų����
				 {0xff, 0xaa, 0x02, 0x06, 0x02},		//����Ԫ�����
				 {0xff, 0xaa, 0x03, 0x07, 0x00},		//���ûش�����20HZ
				 {0xff, 0xaa, 0x01, 0x08, 0x00},		//���ýǶȲο�
			     {0xFF, 0xAA, 0x04, 0x06, 0x00}};		//���ò�����Ϊ115200		
*/		
	for(i=0; i<5; i++)
	{
		UART4_SendChar(Calibration_IMU[i]);	
	}
}

/*
 @ describetion: Xiaoyuan uart interrupt function
 @ param:  none
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void UART4_IRQHandler(void)
*/
unsigned short UART4_ReceiveSize = 0;
unsigned short i = 0;
void UART4_IRQHandler(void)                	
{
	if(USART_GetITStatus(UART4, USART_IT_IDLE) != RESET)  
	{
		(void)UART4->SR; 														// clear usart free interrupt
		(void)UART4->DR; 
		
		LED2 = ~LED2;
		
		DMA_Cmd(DMA1_Stream2, DISABLE); 
		UART4_ReceiveSize = DMA_USART_RX_SIZE - DMA_GetCurrDataCounter(DMA1_Stream2); 
		DMA_SetCurrDataCounter(DMA1_Stream2, DMA_USART_RX_SIZE);
		
		USART_ITConfig(UART4, USART_IT_IDLE, ENABLE); 
	} 
}

