#include "Xiaoyuan_moto.h"
#include "Xiaoyuan_usart.h"
#include "Xiaoyuan_led.h"
#include "Xiaoyuan_pid.h"
#include "Xiaoyuan_encoder.h"
#include "Xiaoyuan_can.h"
__Robot_Feedback_Information_Str Left_Feedback_Information_Str;
__Robot_Feedback_Information_Str Right_Feedback_Information_Str;

/*
 @ describetion: DAC moto control channel init
 @ param: none
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Moto_PWM_Init(unsigned int Prescaler, unsigned int Period
*/
void Moto_Gpio_Init()
{
	GPIO_InitTypeDef  GPIO_InitStructure_gpio;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOE , ENABLE);
	
	GPIO_InitStructure_gpio.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure_gpio.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure_gpio.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure_gpio.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure_gpio.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOE, &GPIO_InitStructure_gpio);	
	
	GPIO_InitStructure_gpio.GPIO_Pin =  GPIO_Pin_12 | GPIO_Pin_13;
	GPIO_Init(GPIOB, &GPIO_InitStructure_gpio);	
}

/*
 @ describetion: DAC moto control channel init
 @ param: none
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Moto_DAC_Init()
*/
void Moto_DAC_Init()
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	DAC_InitTypeDef DAC_InitType;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	DAC_InitType.DAC_Trigger=DAC_Trigger_None;	
	DAC_InitType.DAC_WaveGeneration=DAC_WaveGeneration_None;
	DAC_InitType.DAC_LFSRUnmask_TriangleAmplitude=DAC_LFSRUnmask_Bit0;
	DAC_InitType.DAC_OutputBuffer=DAC_OutputBuffer_Disable ;	
	DAC_Init(DAC_Channel_1,&DAC_InitType);	 

	DAC_Cmd(DAC_Channel_1, ENABLE);  
	DAC_SetChannel1Data(DAC_Align_12b_R, 0); 
	
	Moto_Gpio_Init();
}

/*
 @ describetion: DAC moto control channel output
 @ param: unsigned short vol
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Xiaoyuan_DAC_Output(unsigned short vol)
*/
void Xiaoyuan_DAC_Output(unsigned short vol)
{
	double temp=vol;
	temp/=1000;
	temp=temp*4096/3.3;
	DAC_SetChannel1Data(DAC_Align_12b_R,temp);
}

/*
 @ describetion: Moto footboard control function
 @ param: bool enable
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-4-14
 @ function : void Moto_FootBoard_Control(unsigned short value)
*/
void Moto_FootBoard_Control(unsigned short value)
{
	float FootBoard_ADC_Value;
	
	if(value > 1500)
	{
		FootBoard_ADC_Value = (float)(value-1300)*0.001f;
		(FootBoard_ADC_Value > Speed_Limit)?(FootBoard_ADC_Value = Speed_Limit):(FootBoard_ADC_Value = FootBoard_ADC_Value);
			
		(FangxiangFlag)?\
		(Xiaoyuan_moto_Control_speed(MOTO_Current_Wheel_Speed, FootBoard_ADC_Value)):\
		(Xiaoyuan_moto_Control_speed(MOTO_Current_Wheel_Speed, -FootBoard_ADC_Value));
	}
	else
	{
		Xiaoyuan_moto_Control_speed(MOTO_Current_Wheel_Speed, 0.0);
	}
}


/*
 @ describetion: Motp driver power enable function
 @ param: bool enable
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Moto_Driver_Enable(bool enable)
*/
void Moto_Set_Speed(short Dacvalue)
{
	if(fabs(Dacvalue) >= 1)
	{
		(Dacvalue < 0)?(MOTO_GPIO_A2 = 0, MOTO_GPIO_A1 = 1):(MOTO_GPIO_A2 = 1, MOTO_GPIO_A1 = 0);
		Xiaoyuan_DAC_Output(fabs(Dacvalue));
	}
	else
	{ 
		Xiaoyuan_DAC_Output(0);
	}
}

/*
 @ describetion: Diversion Moto usart init
 @ param: u32 bound
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Robot_Diversion_Moto_Init(u32 bound)
*/
void Robot_Diversion_Moto_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE); 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART6,ENABLE);
 
	GPIO_PinAFConfig(GPIOC,GPIO_PinSource6 ,GPIO_AF_USART6); 
	GPIO_PinAFConfig(GPIOC,GPIO_PinSource7 ,GPIO_AF_USART6); 
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOC,&GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	
	USART_Init(USART6, &USART_InitStructure);
	
	USART_Cmd(USART6, ENABLE);  
	USART_ITConfig(USART6, USART_IT_RXNE, ENABLE);

	NVIC_InitStructure.NVIC_IRQChannel = USART6_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority =0;		
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		
	NVIC_Init(&NVIC_InitStructure);	
}

/*
* describetion: usart send a char data 
* param: b:data
* return: none
* author: Xuewei Zhou
* date : 2016-11-29
*/
void USART6_SendChar(unsigned char b)
{
    while (USART_GetFlagStatus(USART6, USART_FLAG_TC) == RESET);
			USART_SendData(USART6,b);
}

/*
 @ describetion: final Diversion Moto control function
 @ param: u32 bound
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Final_Diversion_Control(short Commend)

	-700----------0-----------700
	�� 67----------------------71
		1�ȶ�Ӧ700/69 = 10.14
*/

void Final_Diversion_Control(short Commend)
{
	unsigned char Buffer[32] = 	{	0x8a, 0x8b, 0x1c, 0x80, 0x00, 0x01, 0x00, 0x00, 0x00, 0x03, 
									0x00, 0x04, 0x00, 0x05, 0x00, 0x06, 0x00, 0x07, 0x00, 0x08, 
									0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
									0x00, 0x00
								};
	char i = 0;
	
	// 1.loading protocl speed
	Buffer[6] = (unsigned char )((Commend >> 8) & 0x00ff);
	Buffer[7] = (unsigned char )((Commend >> 0) & 0x00ff);
	
	// 2.Calculation check sum
	for(i=0; i<SEND_USART_DATA_SIZE-1; i++)	
	{
		Buffer[31] += (unsigned char)Buffer[i];
	}
		
	// 3.Send data to moto driver
	for(i=0; i<SEND_USART_DATA_SIZE; i++)
	{
		USART6_SendChar(Buffer[i]);
	}
}



unsigned char Uart_Recive[50];
short Get_Encoder_Data = 0;

void USART6_IRQHandler(void)                	
{
	static unsigned char count = 0, i = 0;
	unsigned int header = 0;
	unsigned char check_sum = 0;

	if(USART_GetITStatus(USART6, USART_IT_RXNE) != RESET)  
	{
		Uart_Recive[count] = USART_ReceiveData(USART6);
		(Uart_Recive[0] != 0x88)?(count=0):(count++);
		
		if (count == GET_USART_DATA_SIZE)
		{
			// 1.Calculation protocl header      
			header = Uart_Recive[0]<<24 | Uart_Recive[1]<<16 |
					 Uart_Recive[2]<<8  | Uart_Recive[3]<<0;
			Get_Encoder_Data = header;
	
			// 2.Judge protocl header
			if (GET_USART_ENCODER_HEADER == header)	
			{
				// 3.Calculation protocl check sum 
				for(i = 0; i < GET_USART_DATA_SIZE-1; i++)
					check_sum += Uart_Recive[i];
				// 4.Judge protocl check sum 
				if(check_sum == Uart_Recive[GET_USART_DATA_SIZE-1])
				{
					Get_Encoder_Data = (short)(Uart_Recive[15]<<8 | Uart_Recive[16]<<0);
//					LED3 = ~LED3;
				}
			}
			count = 0;	
		}
    } 

//add by gujin		
		if(USART_GetFlagStatus(USART6,USART_FLAG_ORE) == SET)
  {
      USART_ClearFlag(USART6,USART_FLAG_ORE);
      USART_ReceiveData(USART6);
  }
}



