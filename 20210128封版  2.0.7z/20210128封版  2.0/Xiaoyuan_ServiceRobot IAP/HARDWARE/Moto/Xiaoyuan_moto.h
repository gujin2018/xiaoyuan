#ifndef __XIAOYUAN_MOTO_H
#define __XIAOYUAN_MOTO_H 	

#include <string.h> 
#include <stdbool.h>
#include <math.h>
#include "Xiaoyuan_sys.h"


#define ENCODER_TTL_COUNT_VALUE	   	8000.0f
#define ROBOT_INITIATIVE_DIAMETER	0.25f	//������ֱ��	
#define ROBOT_DRIVEN_DIAMETER		0.05f	//�Ӷ���ֱ��
#define CONTROL_TIMER_CYCLE			0.05f	
#define Pi_v						3.1415f





typedef struct _Robot_Feedback_Information
{
	short Robot_Encoder_Val;
	float Current_Wheel_Speed;
	float Target_Wheel_Speed;

}__Robot_Feedback_Information_Str;

extern __Robot_Feedback_Information_Str Left_Feedback_Information_Str;
extern __Robot_Feedback_Information_Str Right_Feedback_Information_Str;

extern short Get_Encoder_Data;
	


#define BRAKING_SOURCE_EN 		PEout(8)	//�����е����ʹ��

#define MOTO_GPIO_A1			PBout(12)
#define MOTO_GPIO_A2			PBout(13)

#define Moto_Driver_Enable(enable) ((enable)?(MOTO_GPIO_A2 = MOTO_GPIO_A1 = 1):(MOTO_GPIO_A2 = MOTO_GPIO_A1 = 0))	//����������ɲ��ʹ��


#define SEND_USART_DATA_SIZE 		32
#define GET_USART_DATA_SIZE  		24
#define GET_USART_ENCODER_HEADER    0X88A11400


#define Base_Width	0.493f
#define Speed_Limit	1.1f

extern short Angle_Offest_Value;


void Moto_DAC_Init(void);
void Xiaoyuan_DAC_Output(unsigned short vol);
void Moto_Set_Speed(short Dacvalue);
void Robot_Diversion_Moto_Init(u32 bound);
void USART6_SendChar(unsigned char b);
void Final_Diversion_Control(short Commend);
void Moto_FootBoard_Control(unsigned short value);

#endif
