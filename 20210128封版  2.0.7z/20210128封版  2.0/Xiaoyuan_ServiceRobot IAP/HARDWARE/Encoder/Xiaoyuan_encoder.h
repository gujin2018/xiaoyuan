#ifndef __XIAOYUAN_ENCODER_H
#define __XIAOYUAN_ENCODER_H 	

#include "Xiaoyuan_sys.h"

/* 
 @	 moto |  port  |   A   |   B   |  tim  |
 @	 left |  PBin  |  PB6  |  PB7  | TIM4  |
 @  right |  PCin  |  PC6  |  PC7  | TIM3  |
*/
extern float MOTO_Current_Wheel_Speed;

void LeftMoto_Encoder_Input_init(void);
void RightMoto_Encoder_Input_init(void);

void Xiaoyuan_Encoder_Start(void);
void Xiaoyuan_Encoder_Get_CNT(void);

#endif
