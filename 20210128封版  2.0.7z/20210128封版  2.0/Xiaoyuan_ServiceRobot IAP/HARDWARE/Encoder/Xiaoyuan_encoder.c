
#include "Xiaoyuan_encoder.h"
#include "Xiaoyuan_moto.h"


/*
 @ describetion:left moto encoder input TIM4 configure 
 @ param: float Dacvalue
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void LeftMoto_Encoder_Input_init(void)
*/
void RightMoto_Encoder_Input_init(void)
{
	GPIO_InitTypeDef gpio;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3 ,ENABLE);

	gpio.GPIO_Pin 	= GPIO_Pin_6 | GPIO_Pin_7;
	gpio.GPIO_Mode 	= GPIO_Mode_AF;
	gpio.GPIO_OType = GPIO_OType_PP;
	gpio.GPIO_PuPd 	= GPIO_PuPd_UP;
	gpio.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOA,&gpio);

	GPIO_PinAFConfig(GPIOA, GPIO_PinSource6,  GPIO_AF_TIM3);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource7,  GPIO_AF_TIM3);

	TIM_EncoderInterfaceConfig(TIM3, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);

	TIM_Cmd(TIM3, ENABLE);
}

/*
 @ describetion:Right moto encoder input TIM3 configure 
 @ param: float Dacvalue
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void RightMoto_Encoder_Input_init(void)
*/
void LeftMoto_Encoder_Input_init(void)
{
	GPIO_InitTypeDef gpio;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4 ,ENABLE);

	gpio.GPIO_Pin 	= GPIO_Pin_6 | GPIO_Pin_7;
	gpio.GPIO_Mode 	= GPIO_Mode_AF;
	gpio.GPIO_OType = GPIO_OType_PP;
	gpio.GPIO_PuPd 	= GPIO_PuPd_UP;
	gpio.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOB,&gpio);

	GPIO_PinAFConfig(GPIOB, GPIO_PinSource6,  GPIO_AF_TIM4);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource7,  GPIO_AF_TIM4);

	TIM_EncoderInterfaceConfig(TIM4, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);

	TIM_Cmd(TIM4, ENABLE);
}

/*
 @ describetion: Encoder count start
 @ param:  none
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Xiaoyuan_Encoder_Start(void)
*/
void Xiaoyuan_Encoder_Start(void)
{
    TIM3->CNT = 0x7fff;
	TIM4->CNT = 0x7fff;
}

/*
 @ describetion: Get encoder value
 @ param:  NONE
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void  Xiaoyuan_Encoder_Get_CNT(void)
*/
float MOTO_Current_Wheel_Speed = 0.0f;
void  Xiaoyuan_Encoder_Get_CNT(void)
{
	Left_Feedback_Information_Str.Robot_Encoder_Val  = (TIM4->CNT)-0x7fff;
	Right_Feedback_Information_Str.Robot_Encoder_Val = (TIM3->CNT)-0x7fff;
	
	Left_Feedback_Information_Str.Current_Wheel_Speed = 
	-((ROBOT_DRIVEN_DIAMETER  *Pi_v * (Left_Feedback_Information_Str.Robot_Encoder_Val / ENCODER_TTL_COUNT_VALUE))/CONTROL_TIMER_CYCLE);
	
	Right_Feedback_Information_Str.Current_Wheel_Speed = 
	-((ROBOT_DRIVEN_DIAMETER  *Pi_v * (Right_Feedback_Information_Str.Robot_Encoder_Val / ENCODER_TTL_COUNT_VALUE))/CONTROL_TIMER_CYCLE);
	
	MOTO_Current_Wheel_Speed = (Right_Feedback_Information_Str.Current_Wheel_Speed + Left_Feedback_Information_Str.Current_Wheel_Speed)/2.0f;
	
	TIM3->CNT = 0x7fff;
	TIM4->CNT = 0x7fff;
}


