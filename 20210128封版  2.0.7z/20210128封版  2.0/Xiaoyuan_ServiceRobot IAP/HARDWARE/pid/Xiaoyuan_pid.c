#include "Xiaoyuan_pid.h"
#include "Xiaoyuan_moto.h"
#include "Xiaoyuan_usart.h"
#include "Xiaoyuan_led.h"
#include "Xiaoyuan_can.h"		
#include "Xiaoyuan_gpio.h"

float ESC_output_DAC = 0;
float L_Error = 0;
float I_Error = 0;
float Current_Limt = 0.0;

float l_p = 0.0f, l_I = 0.0f;

int Limit_Count_Timer = 0;
#define DuZhuan_Sleep_Timer 	5	//5s

//#define _Debug_LineShow_

void Xiaoyuan_moto_Control_speed(float current_speed,float target_speed )
{
	float P_Error = 0;
	float add   = 0; 
	
	//Moto start param and Moto stop param
	(fabs(target_speed) >= 0.001)?(l_p = 165.9f, l_I = 13.3f):(l_p = 135.9f, l_I = 3.5f);		//125.9  3.9
	
	//Update the current one-two third-order error for the current proportional integral and differential calculation
	P_Error = target_speed - current_speed;
	I_Error = P_Error - L_Error;

	//calculation current proportional integral and differential 
	add = P_Error*l_p + L_Error*l_I;

	
	//���Ӽ�ͣ��ť���ж��ź�
//	(!EMERGENCY_STOP_SWOTCH || (Reci_CAN1.Transmission_Buffer[0]==0))?(ESC_output_DAC += add):(ESC_output_DAC = 0);
	(Reci_CAN1.CAN_Frame_Stru_.data3 == 0)?(ESC_output_DAC += add):(ESC_output_DAC = 0);
	//ͣ�������������
	if(ESC_output_DAC != 0)
	(ESC_output_DAC > 0)?(ESC_output_DAC -= 1.5f):(ESC_output_DAC += 1.5f);
	 
	//Moto Max current Limt
	Current_Limt = fabs(current_speed) * 600 + 900;
	if(fabs(ESC_output_DAC) > Current_Limt)
	{
		(ESC_output_DAC > 0)?(ESC_output_DAC = Current_Limt):(ESC_output_DAC = -Current_Limt);
	}
	
	L_Error = P_Error;
	
	if(ESC_output_DAC > ESC_OUTPUT_DAC_LIMT)	ESC_output_DAC = ESC_OUTPUT_DAC_LIMT;		
	else if(ESC_output_DAC < -ESC_OUTPUT_DAC_LIMT)	ESC_output_DAC = -ESC_OUTPUT_DAC_LIMT;
	
	#ifdef _Debug_LineShow_
	{	
		send_data[0] = current_speed;
		send_data[1] = target_speed;
		send_data[2] = add*0.001f;
		send_data[3] = ESC_output_DAC * 0.001f;
		send_data[4] = (float)MOTO_GPIO_A1*0.5f;
		send_data[5] = (float)MOTO_GPIO_A2*0.5f;
		
		shanwai_send_data1((uint8_t*)&send_data,sizeof(send_data));
	}
	#endif
	
	// moto control function
	Moto_Set_Speed(ESC_output_DAC);
}
