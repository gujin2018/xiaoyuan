#ifndef __XIAOYUAN_PID_H
#define __XIAOYUAN_PID_H


#include "Xiaoyuan_sys.h"


#define ESC_OUTPUT_DAC_LIMT	3300	//0-3.3v


extern float ESC_output_DAC;
void Xiaoyuan_moto_Control_speed(float current_speed,float target_speed);

		 				    
#endif


