#include "Xiaoyuan_sensor.h"
#include "Xiaoyuan_adc.h"
#include "Xiaoyuan_usart.h"	
#include <math.h>
/** 
 @ US1 - PC0
 @ US2 - PC1
 @ US3 - PA2
 @ US4 - PA3
 @ US5 - PA5
 @ ACC - PC2
 @ Current - PC4 
**/

void Sensor_update(void)
{
	char i;
	for(i=0;i<5;i++)
	{
		//[x(v)max = 2.5v]: x(v) / 2.5v = y(m) / 3.07   ==> y(m) =  x(v) / 2.5v *3.07 ==> y(cm) = y(m) * 100
		
		if(ADC_ConvertedValue[i]>2500)		//over range 2.5m     3m ==> 2.5v ==> ADC_ConvertedValue=3100
		{
			Send_Commnication_move_Union.Commnication_move_Stru_.Distence_Sensor_buf[i] = 0xff;
		}
		else if(ADC_ConvertedValue[i] != 0)
		{	
			//Send_Commnication_move_Union.Commnication_move_Stru_.Distence_Sensor_buf[i]	= (unsigned char)(((float)ADC_ConvertedValue[i]	/ 4096.0f) * 3.3f / 2.5f * 3.07f * 100.0f) ;
			Send_Commnication_move_Union.Commnication_move_Stru_.Distence_Sensor_buf[i]	= (unsigned char)((float)(ADC_ConvertedValue[i])	* 0.099f) ;
		}
	}
}

