#ifndef _XIAOYUAN_SENSOR_H_
#define _XIAOYUAN_SENSOR_H_
#include "Xiaoyuan_sys.h"






void Sensor_update(void);
#endif


