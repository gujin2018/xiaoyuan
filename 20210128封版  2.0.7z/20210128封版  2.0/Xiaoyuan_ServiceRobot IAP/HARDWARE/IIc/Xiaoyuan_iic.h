#ifndef __XIAOYUAN_IIC_H
#define __XIAOYUAN_IIC_H

#include "Xiaoyuan_sys.h" 

/**
 @ SCL  PA1
 @ SDA  PA0
**/
   	   		   
//IO��������
#define SDA_IN()  {GPIOA->MODER&=~(3<<(0*2));GPIOA->MODER|=0<<0*2;}		//PA0����ģʽ
#define SDA_OUT() {GPIOA->MODER&=~(3<<(0*2));GPIOA->MODER|=1<<0*2;}     //PA0���ģʽ


#define IIC_SCL    	PAout(1) //SCL
#define IIC_SDA    	PAout(0) //SDA

#define READ_SDA   PAin(0)  //����SDA 


void Xiaoyuan_IIC_Init(void);                			 
void IIC_Start(void);				
void IIC_Stop(void);	  			
void IIC_Send_Byte(u8 txd);			
unsigned char IIC_Read_Byte(unsigned char ack);
unsigned char IIC_Wait_Ack(void); 				
void IIC_Ack(void);					
void IIC_NAck(void);				


#endif
















