#include "Xiaoyuan_led.h"
#include "Xiaoyuan_delay.h"
#include "Xiaoyuan_moto.h"
#include "Xiaoyuan_usart.h"
#include "Xiaoyuan_moto.h"
#include "Xiaoyuan_gpio.h"
#include "Xiaoyuan_can.h"

/**
 @ LED1 = PE2
 @ LED2 = PE3
 @ LED3 = PE4
 @ LED4 = PE5
 
 @ HALL_A = PB10
**/

void Xiaoyuan_LED_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE , ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
}
/*
 @ describetion: Xiaoyuan KEYEXIT_Init function
 @ param:  none
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Xiaoyuan_LED_Init(void)
*/
void Xiaoyuan_KEYEXIT_Init(void)
{
	GPIO_InitTypeDef   GPIO_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;
	EXTI_InitTypeDef   EXTI_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Pin =   GPIO_Pin_2 |GPIO_Pin_3 ; //key on board & jiting
	GPIO_Init(GPIOD, &GPIO_InitStructure);	
	
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOD, EXTI_PinSource2);	//����

	//key on board
	EXTI_InitStructure.EXTI_Line = EXTI_Line2;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; 
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}


void EXTI2_IRQHandler(void)  					//key on board
{	
	if(EXTI_GetITStatus(EXTI_Line2)!=RESET)    
    { 
		delay_ms(5);
		Send_CAN1.CAN_Frame_Stru_.data0 =0xFA;
		(KEY_ON_BOARD)?(Send_CAN1.CAN_Frame_Stru_.data1 |=(1<<7)):(Send_CAN1.CAN_Frame_Stru_.data1 &=~(1<<7));
		CAN1_Send_Msg(Send_CAN1.Transmission_Buffer,8);		
		LED1 = !LED1;
		__set_FAULTMASK(1);
		NVIC_SystemReset();
		Send_CAN1.CAN_Frame_Stru_.data1=0x00;
		EXTI_ClearITPendingBit(EXTI_Line2);		
    }
}
bool SteerCalibFlag = false;



/*
 @ describetion: Xiaoyuan KEYEXIT_Init function
 @ param:  none
 @ return: none
 @ author: Xuewei Zhou
 @ date : 2019-3-14
 @ function : void Xiaoyuan_LED_Init(void)
*/
short Angle_Offest_Value = 0;


