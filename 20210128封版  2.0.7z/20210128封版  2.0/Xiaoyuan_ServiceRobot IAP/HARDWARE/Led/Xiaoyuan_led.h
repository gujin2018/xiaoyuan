#ifndef _XIAOYUAN_LED_H_
#define _XIAOYUAN_LED_H_
#include "Xiaoyuan_sys.h"



#define KEY_ON_BOARD 	PDin(2)	


#define XISHUI_KEY_SWITCH			PDin(1)
#define SHUAPAN_KEY_SWITCH			PDin(5)
#define FANGXIANG_KEY_SWITCH		PDin(6)
#define MAUUAL_KEY_SWITCH			PDin(7)

#define EMERGENCY_STOP_SWOTCH		PDin(3)	//���ڵ��PID��������ж�
	
#define LED1	PEout(2)
#define LED2	PEout(3)
#define LED3	PEout(4)
#define LED4	PEout(5)

void Xiaoyuan_KEYEXIT_Init(void);
void Xiaoyuan_LED_init(void);

#endif


