#ifndef __XIAOYUAN_DELAY_H
#define __XIAOYUAN_DELAY_H 	

#include "Xiaoyuan_sys.h"  
	 
void Keysi_delay_init(u8 SYSCLK);
void delay_ms(u16 nms);
void delay_us(u32 nus);

#endif





























