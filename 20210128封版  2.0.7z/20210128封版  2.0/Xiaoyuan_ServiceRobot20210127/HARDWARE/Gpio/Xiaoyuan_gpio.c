#include "Xiaoyuan_gpio.h"

void Xiaoyuan_GPIO_Init(void)
{    	 
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOD | RCC_AHB1Periph_GPIOE, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	//24V_Enable:PE0
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;											
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	//JDQ:PB3_PB9,PD7,   Totle:8��
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;											
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;												 				 	 		 
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	

}

/*
 @ describetion: Xiaoyuan INPUT_Init function
 @ param:  
 @ return:  
 @ date :  
 @ function : 
*/
void Xiaoyuan_INPUT_Init(void)
{
	GPIO_InitTypeDef   GPIO_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;
	EXTI_InitTypeDef   EXTI_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	
	//INPUT:PC6-PC13 Total:8��
	GPIO_InitStructure.GPIO_Pin =   GPIO_Pin_6 |GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13 ; 
	GPIO_Init(GPIOC, &GPIO_InitStructure);	
	
	//���ⰴ����PD2
	GPIO_InitStructure.GPIO_Pin =   GPIO_Pin_2;
	GPIO_Init(GPIOD, &GPIO_InitStructure);		
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOD, EXTI_PinSource2);	//����

	EXTI_InitStructure.EXTI_Line = EXTI_Line2;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; 
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}


void EXTI2_IRQHandler(void)  					//key on board
{	
	if(EXTI_GetITStatus(EXTI_Line2)!=RESET)    
    { 
//		delay_ms(5);
//			(KEY_ON_BOARD)?(FangxiangFlag = !FangxiangFlag):(FangxiangFlag = FangxiangFlag);
//			(FangxiangFlag == 0)?(LED_Yellow =1 ):(LED_Yellow =0);
//		Send_CAN1.CAN_Frame_Stru_.data0 =0xFA;
//		(KEY_ON_BOARD)?(Send_CAN1.CAN_Frame_Stru_.data1 |=(1<<7)):(Send_CAN1.CAN_Frame_Stru_.data1 &=~(1<<7));
//		CAN1_Send_Msg(Send_CAN1.Transmission_Buffer,8);		
//		__set_FAULTMASK(1);
//		NVIC_SystemReset();
//		Send_CAN1.CAN_Frame_Stru_.data1=0x00;
		EXTI_ClearITPendingBit(EXTI_Line2);		
    }
}







