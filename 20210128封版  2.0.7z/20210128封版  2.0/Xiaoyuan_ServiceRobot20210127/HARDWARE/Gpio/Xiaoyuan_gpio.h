#ifndef _XIAOYUAN_GPIO_H_
#define _XIAOYUAN_GPIO_H_
#include "Xiaoyuan_sys.h"
#define POWER24V_Enable 			GPIOE->BSRRL=GPIO_Pin_0			
#define POWER24V_Disable			GPIOE->BSRRH=GPIO_Pin_0				

#define JDQ_IN1_High 							GPIOB->BSRRL=GPIO_Pin_9	
#define JDQ_IN1_Low 								GPIOB->BSRRH=GPIO_Pin_9	
#define JDQ_IN2_High 							GPIOB->BSRRL=GPIO_Pin_8	
#define JDQ_IN2_Low 								GPIOB->BSRRH=GPIO_Pin_8	
#define JDQ_IN3_High 							GPIOB->BSRRL=GPIO_Pin_7	
#define JDQ_IN3_Low 								GPIOB->BSRRH=GPIO_Pin_7	
#define JDQ_IN4_High 							GPIOB->BSRRL=GPIO_Pin_6	
#define JDQ_IN4_Low 								GPIOB->BSRRH=GPIO_Pin_6	
#define JDQ_IN5_High 							GPIOB->BSRRL=GPIO_Pin_5	
#define JDQ_IN5_Low 								GPIOB->BSRRH=GPIO_Pin_5	
#define JDQ_IN6_High 							GPIOB->BSRRL=GPIO_Pin_4	
#define JDQ_IN6_Low 								GPIOB->BSRRH=GPIO_Pin_4	
#define JDQ_IN7_High 							GPIOB->BSRRL=GPIO_Pin_3	
#define JDQ_IN7_Low 								GPIOB->BSRRH=GPIO_Pin_3	
#define JDQ_IN8_High 							GPIOD->BSRRL=GPIO_Pin_7	
#define JDQ_IN8_Low 								GPIOD->BSRRH=GPIO_Pin_7	
#define  ALL_JDQ_ENABLE									JDQ_IN1_High
#define  ALL_JDQ_DISABLE						  	JDQ_IN1_Low
#define CHARGE_JDQ1_ON         			JDQ_IN2_High
#define CHARGE_JDQ1_OFF       				JDQ_IN2_Low
#define CHARGE_JDQ2_ON         			JDQ_IN3_High
#define CHARGE_JDQ2_OFF       				JDQ_IN3_Low

//INPUT:
#define INPUT1 											PCin(6)
#define INPUT2 											PCin(7)
#define INPUT3 											PCin(8)
#define INPUT4 											PCin(9)
#define INPUT5 											PCin(10)
#define INPUT6 											PCin(11)
//#define INPUT7 											PCin(12)
//#define INPUT8 											PCin(13)
//#define TOTAL_SWITCH 							INPUT1// �ܿ���
#define EMERGENCY_STOP_SWITCH			INPUT1	//��ͣ����
#define TOUCH_SWITCH_FRONT							INPUT3	//����
#define TOUCH_SWITCH_BACK								INPUT4	//����
//#define CHARGE_Position_Flag								  INPUT2 //���λ���ź�
//#define CHARGE_JDQ1_Flag											  PBin(8) //���JDQ�ź�
//#define CHARGE_JDQ2_Flag											  PBin(7) //���JDQ�ź�
//#define ALL_JDQ_Flag											  						PBin(9) //ALL_JDQ�ź�
//extern u8 TOUCH_DETECT_FLAG;

void Xiaoyuan_GPIO_Init(void);
void Xiaoyuan_INPUT_Init(void);

#endif


