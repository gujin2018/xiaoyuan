#include "Xiaoyuan_WeelDrive.h"
#include "Xiaoyuan_usart.h"
#include "Xiaoyuan_can.h"
#include "Xiaoyuan_gpio.h"
#include "Xiaoyuan_battery.h"
#include <math.h> 

int LeftWeel_CurrentSpeedRPM,RightWeel_CurrentSpeedRPM, LeftWeel_TargetSpeedRPM, RightWeel_TargetSpeedRPM; 
float LeftWeel_CurrentSpeedMS,RightWeel_CurrentSpeedMS, LeftWeel_TargetSpeedMS, RightWeel_TargetSpeedMS;

const vu8 speed_zero[] = 			{0X23,0XFF,0X60,0X00,0X00,0X00,0X00,0X00};
const vu8 alarm_clear[] = 		{0X2b,0X40,0X60,0X00,0X80,0X00,0X00,0X00};
const vu8 drive_init[] = 			{0X2b,0X40,0X60,0X00,0X00,0X00,0X00,0X00};
const vu8 drive_set6[] = 			{0X2b,0X40,0X60,0X00,0X06,0X00,0X00,0X00};
const vu8 drive_set7[] = 			{0X2b,0X40,0X60,0X00,0X07,0X00,0X00,0X00};
const vu8 drive_setf[] = 			{0X2b,0X40,0X60,0X00,0X0f,0X00,0X00,0X00};
const vu8 NMT_Start_Left[] = 			{0X01,0X04};   //04 ��ʾID��4
const vu8 NMT_Start_Right[] = 		{0X01,0X05};   //05 ��ʾID��5

vu8 speed_acc[] = 		{0X23,0X83,0X60,0X00,0X00,0X00,0X00,0X00};
vu8 speed_dec[] = 		{0X23,0X84,0X60,0X00,0X00,0X00,0X00,0X00};
vu8 myspeed_smooth[] = {0X2b,0X18,0X20,0X00,0X00,0X00,0X00,0X00};
char Moto_State; //true: enable, false:disable

static void Step_to_Array(int SpeedRPM,vu8* Speed_p)
{
	*(Speed_p+4)=(u8)(SpeedRPM&0xff);	
	*(Speed_p+5)=(u8)(SpeedRPM>>8&0xff);   
	*(Speed_p+6)=(u8)(SpeedRPM>>16&0xff);   
	*(Speed_p+7)=(u8)(SpeedRPM>>24&0xff);   	
}	

static void Speed_Para_Set(u16  acc_time, u16  dec_time, u32  speed_smooth)
{
		/* ���õ�� �Ӽ���ʱ��*/
	Step_to_Array(acc_time,speed_acc);
	Step_to_Array(dec_time,speed_dec);
	CANopen_Send(Send_ID_Left_Weel,8,(vu8 *)speed_acc);	
	CANopen_Send(Send_ID_Left_Weel,8,(vu8 *)speed_dec);	
	CANopen_Send(Send_ID_Right_Weel,8,(vu8 *)speed_acc);	
	CANopen_Send(Send_ID_Right_Weel,8,(vu8 *)speed_dec);	
	
	/* �����ٶ�ƽ��ϵ�� */
	Step_to_Array(speed_smooth,myspeed_smooth);
	CANopen_Send(Send_ID_Left_Weel,8,(vu8 *)myspeed_smooth);	
	CANopen_Send(Send_ID_Right_Weel,8,(vu8 *)myspeed_smooth);	
	
}	

/* ʹ�ܵ�������� */
void Drive_Enable(void)
{
	CANopen_Send(Send_ID_Left_Weel,8,(vu8 *)drive_set6);	
	CANopen_Send(Send_ID_Left_Weel,8,(vu8 *)drive_set7);	
	CANopen_Send(Send_ID_Left_Weel,8,(vu8 *)drive_setf);	

	CANopen_Send(Send_ID_Right_Weel,8,(vu8 *)drive_set6);	
	CANopen_Send(Send_ID_Right_Weel,8,(vu8 *)drive_set7);	
	CANopen_Send(Send_ID_Right_Weel,8,(vu8 *)drive_setf);	
}

/* ȥʹ�ܵ�������ƶ� */
void Drive_Disable(void)
{
	CANopen_Send(Send_ID_Left_Weel,8,(vu8 *)drive_set6);		
	CANopen_Send(Send_ID_Right_Weel,8,(vu8 *)drive_set6);	
}

void Init_Weel(void)
{
/* Ŀ���ٶȽ�Ϊ0 */
	CANopen_Send(Send_ID_Left_Weel,8,(vu8 *)speed_zero);	
	CANopen_Send(Send_ID_Right_Weel,8,(vu8 *)speed_zero);	
	
	/* ������� */	
	CANopen_Send(Send_ID_Left_Weel,8,(vu8 *)alarm_clear);	
	CANopen_Send(Send_ID_Right_Weel,8,(vu8 *)alarm_clear);	
	
	/* ��ʼ�������� */	
	CANopen_Send(Send_ID_Left_Weel,8,(vu8 *)drive_init);	
	CANopen_Send(Send_ID_Right_Weel,8,(vu8 *)drive_init);	
	
	/* ���� �Ӽ���ʱ�� ƽ��ϵ�� */
	Speed_Para_Set(ACC_TIME,DEC_TIME,Speed_Smooth);
	
	/* ���ʹ�� */
	Drive_Enable();
	Moto_State = true; //moto state is enable;
	
	/* ��NMT(�ٶȷ�����ʼ����) */
	CANopen_Send(Send_ID_NMT,2,(vu8 *)NMT_Start_Left);	
	CANopen_Send(Send_ID_NMT,2,(vu8 *)NMT_Start_Right);	
		
}	

vu8 Speed_Left[]	=	{0X23,0XFF,0X60,0X00,0X00,0X00,0X00,0X00};
vu8 Speed_Right[]	=	{0X23,0XFF,0X60,0X00,0X00,0X00,0X00,0X00};
//vu8 Speed_test[]					={0x00,0xDA,0x00,0x11,0x00,0X00,0X00,0X02};
float Recive_Left_SpeedMS,Recive_Right_SpeedMS;
int target_Left_Speed,target_Right_Speed;
char Disable_Moto = 0; //0:enable Moto, 1:disable Moto;
/*��ֱ������������PID���ԣ�����������ټ�PID��*/
void Moto_Final_Control_Data(float Left_SpeedMS, float Right_SpeedMS)
{
	int Left_SpeedRPM				=0;
	int Right_SpeedRPM			=0;	
	
	(fabs(Left_SpeedMS)<Min_Speed_Limit)?(Left_SpeedMS=0):(Left_SpeedMS=Left_SpeedMS);
	(fabs(Right_SpeedMS)<Min_Speed_Limit)?(Right_SpeedMS=0):(Right_SpeedMS=Right_SpeedMS);
	(fabs(Left_SpeedMS)>Max_Speed_Limit)?( (Left_SpeedMS>0)?(Left_SpeedMS=Max_Speed_Limit):(Left_SpeedMS=-Max_Speed_Limit) ):(Left_SpeedMS=Left_SpeedMS);
	(fabs(Right_SpeedMS)>Max_Speed_Limit)?( (Right_SpeedMS>0)?(Right_SpeedMS=Max_Speed_Limit):(Right_SpeedMS=-Max_Speed_Limit) ):(Right_SpeedMS=Right_SpeedMS);
	
	Left_SpeedRPM			=(int)(Left_SpeedMS*60.0f/ Pi /Weel_Diameter);
	Right_SpeedRPM		=(int)(Right_SpeedMS*60.0f/ Pi /Weel_Diameter);	
	
	if(!EMERGENCY_STOP_SWITCH || !TOUCH_SWITCH_FRONT || !TOUCH_SWITCH_BACK || battery2usartdata.back_stop )  //		
	{
	   Left_SpeedRPM = 0.0;
		 Right_SpeedRPM = 0.0;
	}
	
//	if(EMERGENCY_STOP_SWITCH)  //δ����ͣ  ����λ������ʹ��
//	{
//		if(Disable_Moto && Moto_State)
//		{
//			 //disable moto
//			 Drive_Disable();	
//			 Moto_State = false;
//		}
//		if(!Disable_Moto && !Moto_State)
//		{
//			 //Enable moto
//			Drive_Enable();
//			Moto_State = true; //moto state is enable;
//		}
//	}	
//	
	
	if(Moto_State)
	{
		 target_Left_Speed = Left_SpeedRPM;
		 target_Right_Speed = Right_SpeedRPM;
	   Step_to_Array(Left_SpeedRPM,		Speed_Left);	
	   Step_to_Array(Right_SpeedRPM,	Speed_Right);		
		
	   CANopen_Send(Send_ID_Left_Weel,8,Speed_Left);
	   CANopen_Send(Send_ID_Right_Weel,8,Speed_Right);		
	}
	
}

void STOP_Process(void)
{
	static u8 SpeedZeroCnt = 0;
	
	if(EMERGENCY_STOP_SWITCH)   //û�а���ͣ
	{
		SpeedZeroCnt = 0;
		if(!Moto_State)
		{
			 //Enable moto
			Drive_Enable();
			Moto_State = true; //moto state is enable;
		}
		return ;
	}	
	
	if(fabs(LeftWeel_CurrentSpeedMS) < 0.01 && fabs(RightWeel_CurrentSpeedMS) < 0.01)
	{
		if((SpeedZeroCnt++) > 20)
		{
			SpeedZeroCnt = 20;
			if(Moto_State)
			{
				 //disable moto
				 Drive_Disable();	
				 Moto_State = false;
			}	
		}	
	}	
}	



