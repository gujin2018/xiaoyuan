#ifndef __WeelDrive_H
#define __WeelDrive_H

#include "Xiaoyuan_sys.h"

//#define __2Weel
#define Send_ID_NMT 0X000
#define Send_ID_Left_Weel 											0x0604
#define Send_ID_Right_Weel 											0x0605
#define Rec_ID_Left_Weel							 		 0X0184
#define Rec_ID_Right_Weel							  	0x0185

#define ACC_TIME 500   //����ʱ�䣬Ĭ��500ms [0,2000]
#define DEC_TIME 500
#define Speed_Smooth 800 // ƽ��ϵ�� Ĭ��1000 [0,30000]

#define Min_Speed_Limit 0.01f
#define Max_Speed_Limit 1.2f
#define Weel_Diameter 0.173f
#define Pi 3.14f


extern int LeftWeel_CurrentSpeedRPM,RightWeel_CurrentSpeedRPM, LeftWeel_TargetSpeedRPM, RightWeel_TargetSpeedRPM; 
extern float LeftWeel_CurrentSpeedMS,RightWeel_CurrentSpeedMS, LeftWeel_TargetSpeedMS, RightWeel_TargetSpeedMS;;
extern float Recive_Left_SpeedMS,Recive_Right_SpeedMS;
extern int target_Left_Speed,target_Right_Speed;
extern char Disable_Moto;
extern vu8 Speed_Left[],Speed_Right[];
//typedef enum {FALSE = 0,TRUE = 1} bool;
extern char Moto_State;

extern u16 LeftAlarm_Mesg,RightAlarm_Mesg;
///////////////////////////Functions////////////////////////////////////////////
void Init_Weel(void);
void Moto_Final_Control_Data(float Left_SpeedMS, float Right_SpeedMS);
void STOP_Process(void);
void Drive_Disable(void);
void Drive_Enable(void);
#endif

















