#include "Xiaoyuan_led.h"

/**
 @ LED1 = PE2
 @ LED2 = PE3
 @ LED3 = PE4
 @ LED4 = PE5
 
 @ HALL_A = PB10
**/

void Xiaoyuan_LED_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE , ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
}


/*
 @ describetion: Xiaoyuan KEYEXIT_Init function
 @ param:  none
 @ return: none
 @ author: 
 @ date : 
 @ function : void Xiaoyuan_LED_Init(void)
*/


void my_keyinit(void)
{
		GPIO_InitTypeDef   GPIO_InitStructure;
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		GPIO_InitStructure.GPIO_Pin =   GPIO_Pin_2 ; //key on board & jiting
		GPIO_Init(GPIOD, &GPIO_InitStructure);	
}	
uint8_t Key_Scan(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin)
{
		if (GPIO_ReadInputDataBit(GPIOx,GPIO_Pin) == 0 )
		{
			while (GPIO_ReadInputDataBit(GPIOx,GPIO_Pin) == 1);
			return 1;
		}
		else
		return 0;
}
