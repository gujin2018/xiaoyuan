#ifndef _XIAOYUAN_TIME_H_
#define _XIAOYUAN_TIME_H_
#include "Xiaoyuan_sys.h"


void BaseBoard_TIM7_Init(u16 arr,u16 psc);
void TIM6_Init(u16 arr,u16 psc);
extern unsigned int Safeware_Count;
extern unsigned int Commnication_Count;

#endif


