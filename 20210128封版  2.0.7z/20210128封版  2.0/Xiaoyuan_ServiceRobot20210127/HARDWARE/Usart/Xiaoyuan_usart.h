#ifndef __XIAOYUAN_USART_H
#define __XIAOYUAN_USART_H

#include "stdio.h"	
#include "stm32f4xx_conf.h"
#include "Xiaoyuan_sys.h" 
#include <stdbool.h>
	
void Robot_Usart_Init(u32 bound);
void USART1_SendChar(unsigned char b);

#define PROTOCAL_DATA_SIZE		24 	
#define PROTOCAL_HEADER		0XFEFEFEFE
#define PROTOCAL_END	0XDD

#pragma pack(1)
typedef struct _ProtocalData_
{
  unsigned int header;
	float speed_left;
  float speed_right;
  float voltage;
  char reserve[7];
  unsigned char end;	
} ProtocalData;

typedef union _BaseSerialData_
{
  unsigned char buffer[PROTOCAL_DATA_SIZE];
	ProtocalData protocal_data;
} BaseSerialData;

typedef union __Test_Gu{
	unsigned char hex[4];
	float x;
}Test_Gu;

#pragma pack(4)
extern Test_Gu floatto16;
extern BaseSerialData  send_data, receive_data;

extern char LeftCommand[];
extern char RightCommand[];
extern unsigned char debug_flag;
extern unsigned char CAN_status_debug;
extern u8 USART1_Command_Flag,OrginStop,ResetMCUFlag;
extern u8 gogotoback;

void shangwei_send_data_usart1(uint8_t *value,uint32_t size );
void update_debugs(void);
void USART1_APP(u8 version_head,u8 version_base); 
void Debug_Usart_Init(u32 bound);
void USART3_SendChar(unsigned char b);
void print_debug(const char *format, ...);
void Ubuntu_Imformation_RxProcess(void);
void Ubuntu_Imformation_TxProcess(void);
void Ubuntu_Heart_Detect(void);
void debug2host(void);
#endif


