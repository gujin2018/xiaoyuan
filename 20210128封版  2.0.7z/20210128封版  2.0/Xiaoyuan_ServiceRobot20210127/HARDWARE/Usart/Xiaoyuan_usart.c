#include "Xiaoyuan_usart.h"	

#include "Xiaoyuan_time.h"
#include "Xiaoyuan_led.h"
#include "Xiaoyuan_delay.h"
#include "Xiaoyuan_gpio.h"
#include "Xiaoyuan_adc.h"
#include "Xiaoyuan_WeelDrive.h"
#include "Xiaoyuan_battery.h"
#include <math.h>
#include <stdarg.h>


BaseSerialData  send_data, receive_data, u3receive_data;
u8 ResetMCUFlag=0,USART1_DEBUG_FLAG=0;

#if 1           
struct __FILE 
{ 
	int handle; 
}; 

FILE __stdout;       
void _sys_exit(int x) 
{ 
	x = x; 
} 
int fputc(int ch, FILE *f)
{ 	
	while((USART1->SR&0X40)==0);
	USART1->DR = (u8) ch;      
	return ch;
}
#endif
 

/*
* describetion: USART1 initialization function
* param: bound��Baud rate
* return: none
* author: 
* date : 
*/
void Robot_Usart_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE); 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
 
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource10,GPIO_AF_USART1); 
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource9 ,GPIO_AF_USART1); 
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_9; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA,&GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	
	USART_Init(USART1, &USART_InitStructure);
	
	USART_Cmd(USART1, ENABLE);  \
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority =0;		
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		
	NVIC_Init(&NVIC_InitStructure);
	
}

/*
* describetion: usart send a char data 
* param: b:data
* return: none
* author: 
* date : 
*/
void USART1_SendChar(unsigned char b)
{
    while (USART_GetFlagStatus(USART1,USART_FLAG_TC) == RESET);
			USART_SendData(USART1,b);
}

//FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 
//00 9A 99 99 3E 00 00 00 00 CD CC CC 3E 00 00 00 00 00 EE 
unsigned char Rcount = 0;
unsigned char usart1_heart_count = 40;
u8 gogotoback = 0;
void USART1_IRQHandler(void)                	
{
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)  
	{
		receive_data.buffer[Rcount] = USART_ReceiveData(USART1);
		(receive_data.buffer[0] == 0xFE)?(Rcount++):(Rcount = 0);
		if (Rcount == PROTOCAL_DATA_SIZE)
		{	
			if((receive_data.protocal_data.header == PROTOCAL_HEADER) && (receive_data.protocal_data.end == PROTOCAL_END))
			{
			   Recive_Left_SpeedMS = receive_data.protocal_data.speed_left;
				 Recive_Right_SpeedMS = receive_data.protocal_data.speed_right;
				 Disable_Moto = receive_data.protocal_data.reserve[2]; //disable moto, 0:enable moto, 1:diable moto
				 gogotoback = receive_data.protocal_data.reserve[4]; 
				 ResetMCUFlag=receive_data.protocal_data.reserve[6]; 
				 if(ResetMCUFlag==0x99)
				 {
			//			delay_ms(10);		
						__set_FAULTMASK(1);
						NVIC_SystemReset();
				 }else if(ResetMCUFlag==0x55)
				 {
						USART1_DEBUG_FLAG = 1;
				 }else
				 {
						USART1_DEBUG_FLAG = 0;
				 }
				 
				 usart1_heart_count = 0;
				 LED_Yellow = !LED_Yellow;
			}			
			Rcount = 0;
		}
	} 
}

void Ubuntu_Imformation_RxProcess(void)
{
				
}

void print_debug1(const char *format, ...)
{
   char buf[128];
	 uint16_t i = 0;
	 va_list ap;
	 va_start(ap, format);
	 vsnprintf(buf, 128, format, ap);
	
	 while(i<127 && buf[i])
	 {
			USART_SendData(USART1, (u8) buf[i++]);
			while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
	 }
	 va_end(ap);
}


void Ubuntu_Imformation_TxProcess(void)
{
		if(USART1_DEBUG_FLAG == 1)		// DEBUG INFORMATION
		{
			print_debug1("Target_Left: %.2f ,right: %.2f  \r\n",Recive_Left_SpeedMS,Recive_Right_SpeedMS);		
			print_debug1("Current left: %.2f, right: %.2f	 \r\n", LeftWeel_CurrentSpeedMS, RightWeel_CurrentSpeedMS);
			print_debug1("STOP(1:run): %d, Moto_State(0:enable): %d	 \r\n", (int)EMERGENCY_STOP_SWITCH, !Moto_State);
			print_debug1("Battery_Heart(0: disconnnet):%d,SOC:%d,Battery_Current:%dmA, ADC_Voltage:%.2fV \r\n",
																														(Battery_HeartCount >= 10)? 0 : 1,																														
																														battery2usartdata.SOC, \
																														battery2usartdata.current,
																														((float)ADC_ConvertedValue_Filter(0)*3.3f*23.0f/4096.0f));
			return;
		}	
		
	 send_data.protocal_data.speed_left = LeftWeel_CurrentSpeedMS;	
	 send_data.protocal_data.speed_right = RightWeel_CurrentSpeedMS;
	 send_data.protocal_data.reserve[0] = EMERGENCY_STOP_SWITCH; //emergency stop putton information
	 send_data.protocal_data.reserve[1] = battery2usartdata.SOC; //battery SOC
	 send_data.protocal_data.reserve[2] = !Moto_State; // 0: enable, 1:disable;
		send_data.protocal_data.reserve[3] = battery2usartdata.ChargeFlag;
//	 (batteryrecdata.battery_protocal_data.current > 0) ? (send_data.protocal_data.reserve[3] = 0x01) : (send_data.protocal_data.reserve[3] = 0x00);
	 send_data.protocal_data.reserve[4] = battery2usartdata.back_stop;	
	 (Battery_HeartCount >= 10) ? (send_data.protocal_data.reserve[5] = 0xff) : (send_data.protocal_data.reserve[5] = 0x00);	
	 send_data.protocal_data.voltage = ((float)ADC_ConvertedValue_Filter(0)*3.3f*23.0f/4096.0f); //voltage information
	
	 for(u8 i=0; i<PROTOCAL_DATA_SIZE; i++)
	 {
	    USART1_SendChar(send_data.buffer[i]);
	 }		
}


void USART1_APP(u8 version_head,u8 version_base) 
{
		u8 i=0;
		u8 buff[5]={0xAA,0xBB,version_head,version_base,0XEE};
 		for(i=0; i<5; i++)
		USART1_SendChar(buff[i]);
} 


void Debug_Usart_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE); 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);
 
	GPIO_PinAFConfig(GPIOD,GPIO_PinSource8,GPIO_AF_USART3); 
	GPIO_PinAFConfig(GPIOD,GPIO_PinSource9 ,GPIO_AF_USART3); 
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOD,&GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	
	USART_Init(USART3, &USART_InitStructure);
	
	USART_Cmd(USART3, ENABLE);  
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);

	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority =1;		
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		
	NVIC_Init(&NVIC_InitStructure);

}
void USART3_SendChar(unsigned char b)
{
    while (USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);
			USART_SendData(USART3,b);
}




void print_debug3(const char *format, ...)
{
   char buf[128];
	 uint16_t i = 0;
	 va_list ap;
	 va_start(ap, format);
	 vsnprintf(buf, 128, format, ap);
	
	 while(i<127 && buf[i])
	 {
			USART_SendData(USART3, (u8) buf[i++]);
			while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	 }
	 va_end(ap);
}

Test_Gu floatto16;
//********************************************************************************
// UART4 Test 
// faf0:reset
// faf8 :debug_information ��//  faf9 :debug_information ��
// fafe:init_2Moto;
// faf1��left++;					//			  faf2: right++    ��С��λ10000   ���䷶Χ[-60000��60000]
// faf3��speed++; 		//				faf4: speed--    ��С��λ0.1ms
//********************************************************************************
u8 USART3_DEBUG_FLAG=0;
u8 UART3_Count=0;
void USART3_IRQHandler(void)                	
{
	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)  
	{
		u3receive_data.buffer[UART3_Count] = USART_ReceiveData(USART3);
		(u3receive_data.buffer[0] == 0xFE)?(UART3_Count++):(UART3_Count = 0);
		if (UART3_Count == PROTOCAL_DATA_SIZE)
		{	
			if((u3receive_data.protocal_data.header == PROTOCAL_HEADER) && (u3receive_data.protocal_data.end == PROTOCAL_END))
			{
//			   Recive_Left_SpeedMS = receive_data.protocal_data.speed_left;
//				 Recive_Right_SpeedMS = receive_data.protocal_data.speed_right;
//				 Disable_Moto = receive_data.protocal_data.reserve[2]; //disable moto, 0:enable moto, 1:diable moto
				 ResetMCUFlag=u3receive_data.protocal_data.reserve[6]; 
				 if(ResetMCUFlag==0x99)
				 {
			//			delay_ms(10);		
						__set_FAULTMASK(1);
						NVIC_SystemReset();
				 }else if(ResetMCUFlag==0x55)
				 {
						USART3_DEBUG_FLAG = 1;
				 }else
				 {
						USART3_DEBUG_FLAG = 0;
				 }

			}			
			UART3_Count = 0;
		}
	} 
}


void debug2host(void)
{
	if(USART3_DEBUG_FLAG){
			print_debug3("Recive_Left(M/S): %.2f ,right: %.2f  \r\n",Recive_Left_SpeedMS,Recive_Right_SpeedMS);
			print_debug3("Target_Left(RPM): %.2d ,right: %.2d  \r\n",target_Left_Speed,target_Right_Speed);		
			print_debug3("Current left(M/S): %.2f, right: %.2f	 \r\n", LeftWeel_CurrentSpeedMS, RightWeel_CurrentSpeedMS);
//			print_debug3("STOP(1:run): %d, Moto_State(0:enable): %d	 \r\n", (int)EMERGENCY_STOP_SWITCH, !Moto_State);
//			print_debug3("Battery_Heart(0: disconnnet):%d,SOC:%d,Battery_Current:%dmA, ADC_Voltage:%.2fV \r\n",
//																														(Battery_HeartCount >= 10)? 0 : 1,																														
//																														battery2usartdata.SOC, \
//																														battery2usartdata.current,
//																														((float)ADC_ConvertedValue_Filter(0)*3.3f*23.0f/4096.0f));
			print_debug3("Moto_State(0:enable): %d,Battery_Current:%dmA  back_stop:%d\r\n",!Moto_State,battery2usartdata.current,battery2usartdata.back_stop);
	}	

}	
void Ubuntu_Heart_Detect(void)
{
	if(usart1_heart_count++ > 40)
	{		
		 gogotoback = 0;
		 LED_Red=!LED_Red;
	   Recive_Left_SpeedMS = 0.0;
		 Recive_Right_SpeedMS = 0.0;
		 usart1_heart_count = 50;
	}	
	else
	{		
			LED_Red = 0;
	}

}	
