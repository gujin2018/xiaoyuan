#ifndef _XIAOYUAN_LIGHT_H_
#define _XIAOYUAN_LIGHT_H_
#include "Xiaoyuan_sys.h"

#define BLUE_LIGHT_Enable 					GPIOB->BSRRL=GPIO_Pin_9			
#define BLUE_LIGHT_Disable					GPIOB->BSRRH=GPIO_Pin_9				
#define LEFT_LIGHT_Enable 					GPIOB->BSRRL=GPIO_Pin_8			
#define LEFT_LIGHT_Disable					GPIOB->BSRRH=GPIO_Pin_8
#define RIGHT_LIGHT_Enable 					GPIOB->BSRRL=GPIO_Pin_7				
#define RIGHT_LIGHT_Disable					GPIOB->BSRRH=GPIO_Pin_7	

#define HIGH_LEVEL_Enable 					GPIOB->BSRRL=GPIO_Pin_6				
#define LOW_LEVEL_Disable					GPIOB->BSRRH=GPIO_Pin_6

#define BLUE_LIGHT_CONTROL		PBout(9)
#define LEFT_LIGHT_CONTROL		PBout(8)
#define RIGHT_LIGHT_CONTROL		PBout(7)
//#define GET_LEFT		PDin(12)
//#define GET_RIGHT	PDin(10)
void Xiaoyuan_LIGHT_init(void);
void Xiaoyuan_LIGHT_ctrl(void);
#endif


