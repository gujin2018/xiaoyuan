#include "Xiaoyuan_light.h"

#include "Xiaoyuan_gpio.h"
#include "Xiaoyuan_WeelDrive.h"

/**
 @ BLUE_LIGHT = PB9
 @ LEFT_LIGHT = PB8
 @ RIGHT_LIGHT = PB7
 @ high level = PB6
**/

void Xiaoyuan_LIGHT_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB , ENABLE);

	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 |GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	HIGH_LEVEL_Enable; //set JDQ 4: PB6 with high voltage
	BLUE_LIGHT_Enable;
}


void Xiaoyuan_LIGHT_ctrl(void)
{  
	if((LeftWeel_CurrentSpeedMS + RightWeel_CurrentSpeedMS) <= (-0.1f)) //right wheel speed is reverse
	{
			LEFT_LIGHT_CONTROL = 1;
	}
	else if((LeftWeel_CurrentSpeedMS + RightWeel_CurrentSpeedMS) >= 0.1f)
	{
			RIGHT_LIGHT_CONTROL = 1;
	}
	else
	{
			LEFT_LIGHT_CONTROL = 0;
			RIGHT_LIGHT_CONTROL = 0;
	}
}

/*
void Xiaoyuan_LIGHT2_ctrl(void)
{
	
	static unsigned char turn_light_status,turn_light_count;
	static unsigned int forward_light_count;
	if(Left_Feedback_Information_Str.Current_Wheel_Speed >= 0 && Right_Feedback_Information_Str.Current_Wheel_Speed >= 0)
	{
		//	turn left
		if((Left_Feedback_Information_Str.Current_Wheel_Speed - Right_Feedback_Information_Str.Current_Wheel_Speed)  < -0.07f)
		{
			if(turn_light_status != 0xAA)
			{
					turn_light_count++;
					if(turn_light_count ==10)
					{
						RIGHT_LIGHT_Disable;
						LEFT_LIGHT_Enable;
						turn_light_status = 0xAA;
						turn_light_count = 0;
					}
			}
			forward_light_count = Safeware_Count;
		}		
		// 	turn right
		else if((Left_Feedback_Information_Str.Current_Wheel_Speed - Right_Feedback_Information_Str.Current_Wheel_Speed)  > 0.07f)
		{
			if(turn_light_status != 0xBB)
			{
					turn_light_count++;
					if(turn_light_count ==10)
					{
						LEFT_LIGHT_Disable;	
						RIGHT_LIGHT_Enable;
						turn_light_status = 0xBB;
						turn_light_count = 0;		
					}
			}
			forward_light_count = Safeware_Count;
		}	
		//	foward  //after 500ms
		else if(turn_light_status != 0x00) 
		{
				if((Safeware_Count - forward_light_count) >=10)
				{
					LEFT_LIGHT_Disable;
					RIGHT_LIGHT_Disable;
					turn_light_status = 0x00;
					turn_light_count = 0;
				}
		}		
	}		
}	*/

