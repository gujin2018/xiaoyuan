#include "Xiaoyuan_battery.h"
#include "Xiaoyuan_WeelDrive.h"
#include "Xiaoyuan_can.h"
#include "Xiaoyuan_gpio.h"
#include "Xiaoyuan_usart.h"
#include <math.h> 

u8 Cnt1s = 0;

vu8 Battery_All[]							={0X00,0X04,0X16,0X00,0X4f,0X85};
vu8 Battery_Current[]					={0X00,0X04,0X02,0X00,0X40,0X85};
vu8 Battery_EmptyFullTime[]		={0X0f,0X04,0X02,0X00,0X43,0X91};
vu8 Battery_SOCSOH[]					={0X11,0X04,0X02,0X00,0X45,0XB9};
vu8 Battery_AlarmSafety[]			={0X14,0X04,0X02,0X00,0X45,0X75};

BatteryDataCANData batteryrecdata;
Battery2UsartData battery2usartdata;
u8 Battery_HeartCount = 10;
u8 Battery_AllCommand(void)
{
	u8 rec=0;
	if(Battery_HeartCount++ >= 10)
		Battery_HeartCount = 10;
	
	rec = 	CAN_Battery_Send(0x182c1860,Battery_All);

	return (rec == 0 ? 0:1);  //0:normal; 1:error 
}	

u8 Battery_GetInfo(void)
{
	if(Battery_HeartCount >= 10)
	{
		printf("Battery can get info! \r\n");
		return 1;
	}
//	
//	printf("******* \r\n ");
//	for(u8 i = 0; i < battery_RecLen; i++)
//	printf("0x%02X \r\n",batteryrecdata.Battery_RecBuff[i]);
	
	printf("length : %d | %d mA | %d min | %d min | SOC:%d%%  | SOH: %d%% | Alarm: %d | Safety :%d \r\n", \
								batteryrecdata.battery_protocal_data.datalength, \
								batteryrecdata.battery_protocal_data.current, \
								batteryrecdata.battery_protocal_data.TimeToEmpty, \
								batteryrecdata.battery_protocal_data.TimeTOFull, \
								batteryrecdata.battery_protocal_data.SOC, \
								batteryrecdata.battery_protocal_data.SOH, \
								batteryrecdata.battery_protocal_data.Alarm, \
								batteryrecdata.battery_protocal_data.Safety);

	return 0;
}	
u8 SOC_filter(void)
{
	static u8 SOCErrorCnt = 0;
	static u8 last_SOC = 0;
	if((u8)batteryrecdata.battery_protocal_data.SOC != 0){
		SOCErrorCnt = 0;
		last_SOC = (u8)batteryrecdata.battery_protocal_data.SOC;
		return (u8)batteryrecdata.battery_protocal_data.SOC;
	}
	
	if(SOCErrorCnt ++ > 100){
		SOCErrorCnt = 100;
		last_SOC = 0;
		return (u8)batteryrecdata.battery_protocal_data.SOC;
	}
	else{
		return last_SOC;
	}
}	

u8 Charge_filter(void)
{
	static u8 ChargeErrorCnt = 0;
	static int last_Charge = 0;
	if((u8)batteryrecdata.battery_protocal_data.current != 0){
		ChargeErrorCnt = 0;
		battery2usartdata.current = batteryrecdata.battery_protocal_data.current;
		last_Charge = batteryrecdata.battery_protocal_data.current;
		if(batteryrecdata.battery_protocal_data.current > 0) 
			return 0x01; 
		else 
			return 0x00 ;
		}
	
	if(ChargeErrorCnt ++ > 100){
		ChargeErrorCnt = 100;
		battery2usartdata.current = 0;
		last_Charge = 0;
		return 0x00;
	}
	else{
		if(last_Charge > 0) 
			return 0x01; 
		else 
			return 0x00 ;
	}
}	

void BatteryDataProcess(void)
{
	static u8 overload_cnt = 0;
	static u8 download_cnt = 0;
	static u8 lock = 0;
	battery2usartdata.SOC = SOC_filter();
	battery2usartdata.ChargeFlag = Charge_filter();
	
		if(battery2usartdata.current > battery_over_current && battery2usartdata.current < battery_stop_current && gogotoback == 1){		 				//�س����(LeftWeel_CurrentSpeedMS < 0.5 && RightWeel_CurrentSpeedMS < 0.5)�й���
			download_cnt = 0;
			if(overload_cnt++ >= ovload_time){
				battery2usartdata.back_stop = 1;
				overload_cnt = ovload_time;
				lock = 0;
//				//driver disable
//				if(Moto_State)
//				{
//				 //disable moto
//				 Drive_Disable();	
//				 Moto_State = false;
//				}	
			}
		}	
		else {																														//����dwload_time���ͷſ���Ȩ
			overload_cnt = 0;
			if(download_cnt++ >= dwload_time){
				battery2usartdata.back_stop = 0;
				download_cnt = dwload_time;
				if(!lock){
					lock = 1;
//					if(!Moto_State)
//					{
//						 //Enable moto
//						Drive_Enable();
//						Moto_State = true; //moto state is enable;
//					}
				}
			}
		}
}	
