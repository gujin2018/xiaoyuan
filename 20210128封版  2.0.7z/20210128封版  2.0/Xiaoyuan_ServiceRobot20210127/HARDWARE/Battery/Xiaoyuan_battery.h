#ifndef __Battery_H
#define __Battery_H

#include "Xiaoyuan_sys.h"

#define battery_SendID 	0x182C5860
#define battery_RecID 	0x1A0C5860
#define battery_RecID_Offset 	0x1A0C586

#define battery_RecLen 47
#define battery_stop_current -2500
#define battery_over_current -15000
#define ovload_time 2
#define dwload_time 250

typedef struct _Battery2UsartData_
{
	u8 SOC;
	u8 ChargeFlag;
	s32 current;
	u8 back_stop;
} Battery2UsartData;

#pragma pack(1)
typedef struct _BatteryData_
{
  u8 datalength;
	s32 current;
  u32 remain_capacity;
  u32 full_capcacity;	
	u32 charge_current;
	u32 charge_voltage;
	u32 pack_voltage;
	u32 battert_voltage;
	u16 cycle;
	u16 TimeToEmpty;
	u16 TimeTOFull;
	u16 SOC;
	u16 SOH;
	u16 Status;
	u16 Alarm;
	u16 Safety;
	s16 CRC16;
} BatteryprotocalData;

typedef union _BatteryDataCANData_
{
  unsigned char Battery_RecBuff[battery_RecLen];
	BatteryprotocalData battery_protocal_data;
} BatteryDataCANData;
#pragma pack(4)

extern BatteryDataCANData batteryrecdata;
extern Battery2UsartData battery2usartdata;
extern u8 Battery_HeartCount;
extern u8 Cnt1s;
u8 Battery_AllCommand(void);
u8 Battery_GetInfo(void);
void BatteryDataProcess(void);
#endif

















