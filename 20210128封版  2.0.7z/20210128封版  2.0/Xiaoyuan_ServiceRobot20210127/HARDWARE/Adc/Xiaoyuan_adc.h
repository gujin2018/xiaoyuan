#ifndef _XIAOYUAN_ADC_H_
#define _XIAOYUAN_ADC_H_

#define ADC_DataNum 50
#define VAT_OFFSET 0.5f
#include "Xiaoyuan_sys.h"


extern volatile unsigned short ADC_ConvertedValue[ADC_DataNum];
extern volatile float ADC_Value[ADC_DataNum];

#define VAT_CHANNEL							 		ADC_Channel_6                   //ADC_Channel_6      :   PA6 
#define V_24V_CHANNEL 							ADC_Channel_7										//ADC_Channel_7      :   PA7 
#define CURRENT1_CHANNEL	 	ADC_Channel_8                   //ADC_Channel_8      :   PB0 
#define CURRENT2_CHANNEL 		ADC_Channel_9										//ADC_Channel_9      :   PB1 
#define ADCIN1_CHANNEL 					ADC_Channel_0										//ADC_Channel_0      :   PA0 

void Xiaoyuan_ADC_Init(void); 		
u16 ADC_ConvertedValue_Filter(u8 num);
unsigned short Get_Adc(unsigned char ch);
//u8 get_turn_positon(void);
u8 Battery_Detect(void);
#endif


