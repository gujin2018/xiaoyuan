#include "Xiaoyuan_adc.h"


volatile unsigned short ADC_ConvertedValue[ADC_DataNum] = {0};
volatile float ADC_Value[ADC_DataNum] = {0};


static void ADC_DMA(void)
{
	DMA_InitTypeDef DMA_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
	DMA_DeInit(DMA2_Stream0);

	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&(ADC1->DR); 
	DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)&ADC_ConvertedValue; 
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory; 
	DMA_InitStructure.DMA_BufferSize = ADC_DataNum; 
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable; 
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable; 
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;  
	DMA_InitStructure.DMA_Priority = DMA_Priority_High; 
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable; 
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
	DMA_InitStructure.DMA_Channel = DMA_Channel_0;
	DMA_Init(DMA2_Stream0, &DMA_InitStructure);
	DMA_Cmd(DMA2_Stream0, ENABLE); 
}	


static void ADC_GPIO(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 |GPIO_Pin_7 | GPIO_Pin_6 ; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}	
static void ADC_Mode_Init(void)
{
ADC_CommonInitTypeDef ADC_CommonInitStructure;
	ADC_InitTypeDef       ADC_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); 
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC1,ENABLE);	  
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC1,DISABLE);	

	ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
	ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled ; 
	ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div4; 
	ADC_CommonInit(&ADC_CommonInitStructure);

	ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
	ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfConversion = 5;
	ADC_Init(ADC1, &ADC_InitStructure);
}
void Xiaoyuan_ADC_Init(void)
{    	 
	ADC_DMA();
	ADC_GPIO();
	ADC_Mode_Init();
	
	ADC_RegularChannelConfig(ADC1, VAT_CHANNEL,							 	1, ADC_SampleTime_480Cycles );	 
	ADC_RegularChannelConfig(ADC1, V_24V_CHANNEL, 					2, ADC_SampleTime_480Cycles );	
	ADC_RegularChannelConfig(ADC1, CURRENT1_CHANNEL, 	3, ADC_SampleTime_480Cycles );	
	ADC_RegularChannelConfig(ADC1, CURRENT2_CHANNEL, 	4, ADC_SampleTime_480Cycles );	
	ADC_RegularChannelConfig(ADC1, ADCIN1_CHANNEL, 				5, ADC_SampleTime_480Cycles );	
	
	ADC_DMARequestAfterLastTransferCmd(ADC1, ENABLE);
	ADC_DMACmd(ADC1, ENABLE);
	ADC_Cmd(ADC1, ENABLE);
	ADC_SoftwareStartConv(ADC1);
}				


/*
@PARAMETER: NUM�� �ڼ���ͨ�������� ��
0��VAT;  1:24V;    2:CURRENT1;   3:CURRENT2 ;   4:ADCIN1
*/

u16 ADC_ConvertedValue_Filter(u8 num)
{
	u8 i=0;
	u32 adc_conv_filter=0;
  for(i=0;i<10;i++)
		adc_conv_filter +=ADC_ConvertedValue[i*(ADC_DataNum/10)+num];
	adc_conv_filter = adc_conv_filter/10;
	return (u16)adc_conv_filter;
}

unsigned short Get_Adc(unsigned char ch)   
{
	ADC_RegularChannelConfig(ADC1, ch, 1, ADC_SampleTime_480Cycles );	
	ADC_SoftwareStartConv(ADC1);		
	while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC ));
	return ADC_GetConversionValue(ADC1);	
}

/*
������Ԫ﮵�أ�  ����	4.1v ;				������ѹ		3.7v��					��ֹ��ѹ		3.2V(����)
13����                   ����		53.3V; 			������ѹ��48.1v; 				 	��ֹ��ѹ��41.6V
(δ�г��ҷŵ�����ͼ)������ʽ�ŵ�������ƣ�
															�ο�excel
*/

u8 Battery_Detect(void)
{
		float Battery_value = ((float)ADC_ConvertedValue_Filter(4)*3.3f*44.0f/4096.0f)-VAT_OFFSET;
		  
		if(Battery_value>=53.3f && Battery_value<56.5f)										return 100;
		else if(Battery_value>=52.13f && Battery_value<53.3f)					return 90;
		else if(Battery_value>=50.99f && Battery_value<52.13f)				return 80;	
		else if(Battery_value>=49.83f && Battery_value<50.99f)				return 70;	
		else if(Battery_value>=48.68f && Battery_value<49.83f)				return 60;		
		else if(Battery_value>=48.27f && Battery_value<48.68f)				return 50;	
		else if(Battery_value>=47.86f && Battery_value<48.27f)				return 40;		
		else if(Battery_value>=47.45f && Battery_value<47.86f)				return 30;		
		else if(Battery_value>=45.5f && Battery_value<47.45f)					return 20;		
		else if(Battery_value>=43.55f && Battery_value<45.5f)					return 10;			
		else if(Battery_value>=41.6f && Battery_value<43.55f)					return 0;		
		else if(Battery_value>=56.5f)																										return 101;		  //����
		else if(Battery_value<41.6f)																											return 1;					//����
		else 																																													return 0xFF;		//�������ڷ�Χ��
}


