#ifndef __CAN_H
#define __CAN_H	 

#include "Xiaoyuan_sys.h"
#include "stdbool.h"
extern unsigned char swich_mode_flag;

#pragma pack(1)
typedef union __CAN1_Union_
{
	unsigned char Transmission_Buffer[8];
	struct __CAN_Frame_Stru_
	{
		unsigned char data0;	//
		unsigned char data1;	//rec control command	
		unsigned char data2;	//key control command		
		unsigned char data3;								
		float Orientation_Z; 
	}CAN_Frame_Stru_;
}CAN1_Union;	

#pragma pack(4)

extern CAN1_Union Send_CAN1;
extern CAN1_Union Reci_Left,Reci_Right;

//CAN1����RX0�ж�ʹ��
#define CAN1_RX0_INT_ENABLE	1		//0,��ʹ��;1,ʹ��.								    

u8 CAN1_Mode_Init(u8 tsjw,u8 tbs2,u8 tbs1,u16 brp,u8 mode);//CAN��ʼ��

unsigned char  CAN1_Send_Msg(unsigned char * msg,unsigned char  len);						//��������

unsigned char  CAN1_Receive_Msg(unsigned char  *buf);							//��������

void CAN_Ctrl_Send_Alldata(void);
void CAN_Ctrl_Reci_Alldata(void);

u8 CAN1_Send_Commend(u8 id,u32 commend1,u32 commend2);
u8 CANopen_Send(u32 id,u8 length,vu8* p);

u8 CAN_Weel_Send(u32 id,u8 length,vu8* p);
u8 CAN_Battery_Send(u32 id,vu8* p);
#endif

















