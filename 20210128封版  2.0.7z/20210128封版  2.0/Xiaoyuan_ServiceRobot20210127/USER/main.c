#include <math.h>
#include <stdbool.h>
#include <string.h>
#include "Xiaoyuan_sys.h"
#include "Xiaoyuan_delay.h"
#include "Xiaoyuan_usart.h"
#include "Xiaoyuan_led.h"
#include "Xiaoyuan_can.h"
#include "Xiaoyuan_gpio.h"
#include "Xiaoyuan_adc.h"
#include "Xiaoyuan_iwdg.h"
#include "Xiaoyuan_light.h"
#include "Xiaoyuan_WeelDrive.h"
#include "Xiaoyuan_battery.h"

#define _Ubuntu_Commnication_
#define HEAD_VERSION		0X02 
#define SUB_VERSION				0X01
//#define _gujin_change
 
//������
int main(void)
{ 
	SCB->VTOR = FLASH_BASE | 0x10000;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //The system interrupts the packet
	Keysi_delay_init(168);    																						//The tick timer is initialized with a clock frequency of 168M
	Robot_Usart_Init(115200);           															//Serial port 1 initialization, baud rate is 115200, PC communication interface
	
	memset(&send_data, 0 , sizeof(send_data));
	send_data.protocal_data.header = PROTOCAL_HEADER;
	send_data.protocal_data.end = PROTOCAL_END;
	memset(&receive_data, 0, sizeof(receive_data));
	
	USART1_APP(HEAD_VERSION,SUB_VERSION);                   //���Ͱ汾��  

	Debug_Usart_Init(115200);
	Xiaoyuan_LED_init();
	Xiaoyuan_INPUT_Init(); //emergency stop
	Xiaoyuan_ADC_Init(); //voltage 
	Xiaoyuan_LIGHT_init(); //dengdai
	
	CAN1_Mode_Init(CAN_SJW_1tq,CAN_BS2_6tq,CAN_BS1_7tq,6,CAN_Mode_Normal);//CAN��ʼ������ģʽ,������500Kbps    

	delay_ms(2000); //����bootload��Ϳ���ע�͵�
	Init_Weel();	
	
	while(1)
	{	
		IWDG_Feed();
		Ubuntu_Heart_Detect();
		BatteryDataProcess();
 		Ubuntu_Imformation_TxProcess();
		Moto_Final_Control_Data(Recive_Left_SpeedMS, Recive_Right_SpeedMS);	
		STOP_Process();

//	�ƹ� ����
		LED_Green = !LED_Green;
		(battery2usartdata.ChargeFlag == 0) ? (LED_Blue = LED_OFF) : (LED_Blue = LED_ON);
		
//  ��ز��� 1s
		if(Cnt1s++ == 2)
		{
				Cnt1s = 0;
				Battery_AllCommand();
//				Battery_GetInfo();
		}	
		
		debug2host();

		
//	50ms ��ʱ		
		delay_ms(50);
 	}
}

